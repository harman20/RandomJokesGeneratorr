# Jokes-Generator

- It is a basically a webpage which displays different jokes on click.It generates different jokes on each click by fetching the data
 through API's.

# Technologies User
- HTML
- JQUERY
- API
